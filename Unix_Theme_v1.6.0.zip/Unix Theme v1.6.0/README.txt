**/ Thanks for buying Unix for Pterodactyl \**

Before proceeding with installation make sure you have checked the following things:

* Make sure you're running the latest version of Pterodactyl
* Make sure you don't have any other theme installed


Installation:

1. Open the "Pterodactyl" Folder found in this directory
2. Upload all the folders you see to "/var/www/pterodactyl" ( Enable option to overwrite old files )
3. Open Command Line and run the following command: cd /var/www/pterodactyl && php artisan migrate
4. You'll see that Unix is now Installed, however there is one more step left to get the sidebar working,
   please follow this guide on Pterodactyl website https://pterodactyl.io/community/customization/panel.html
5. Your done!

Need help? Join our discord: LocalHost#8547 